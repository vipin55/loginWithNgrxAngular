export class Login {
    email?: string;
    firstName?: string;
    lastName?: string;
    password?: string;
    date?: Date;
}
